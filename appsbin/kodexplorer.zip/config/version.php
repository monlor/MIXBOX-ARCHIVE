<?php
define('KOD_VERSION','1.12');
define('KOD_VERSION_BUILD','0903');
// define('KOD_VERSION_BUILD',time());