<?php 
 return array (
  0 => 'id',
  1 => 'type',
  2 => 'key',
  3 => 'value',
  4 => 'createTime',
  5 => 'modifyTime',
  '_autoinc' => true,
  '_pk' => 'id',
  '_type' => 
  array (
    'id' => 'int(11) unsigned',
    'type' => 'varchar(50)',
    'key' => 'varchar(255)',
    'value' => 'text',
    'createTime' => 'int(11) unsigned',
    'modifyTime' => 'int(11) unsigned',
  ),
);