<?php

class DPlayerPlugin extends PluginBase{
	function __construct(){
		parent::__construct();
	}
	public function regist(){
		$this->hookRegist(array(
			'user.commonJs.insert' => 'DPlayerPlugin.echoJs',
		));
	}
}