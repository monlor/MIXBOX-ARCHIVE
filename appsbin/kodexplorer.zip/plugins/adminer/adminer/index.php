<?php

// include('../../../config/config.php');
// Action('user.sso')->checkAuthPlugin('adminer');

// include('../../../app/api/KodSSO.class.php');
// $sso = new KodSSO();
// $sso->checkAuthPlugin('adminer');

// echo "hello";
// X-Frame-Options 去除;
// https://github.com/pematon/adminer-plugins
include('./adminer.php.txt');