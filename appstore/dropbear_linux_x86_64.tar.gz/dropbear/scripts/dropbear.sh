#!/bin/sh 
source "$(mbdb get mixbox.main.path)"/bin/base
eval `mbdb export dropbear`
[ -z "${port}" ] && port=1022

get_config() {

    logsh "【$service】" "检查${appname}配置文件中..."
    [ ! -f $CONF/dropbear_rsa_host_key -a ! -f /etc/dropbear/dropbear_rsa_host_key ] && logsh "【$service】" "缺失证书文件无法启动！" && exit 1
    [ ! -f  $CONF/dropbear_dss_host_key -a ! -f /etc/dropbear/dropbear_dss_host_key ] && logsh "【$service】" "缺失证书文件无法启动！" && exit 1
    [ ! -f $BIN/${appname} ] && cp -rf /usr/sbin/dropbear $BIN/${appname}
    # [ ! -f $BIN/dropbearkey ] && cp -rf /usr/bin/dropbearkey $BIN/dropbearkey
    [ ! -f $CONF/dropbear_rsa_host_key ] && cp -rf /etc/dropbear/dropbear_rsa_host_key $CONF/dropbear_rsa_host_key
    [ ! -f $CONF/dropbear_dss_host_key ] && cp -rf /etc/dropbear/dropbear_dss_host_key $CONF/dropbear_dss_host_key

}

start() {

    logsh "【$service】" "正在启动${appname}服务... "
    # cru a "${appname}" "0 6 * * * $FUN/${appname}.sh restart"
    # Scripts Here
    logsh "【$service】" "服务启动端口号为：${port}"
    get_config
    if [ "$modify_passwd" = '1' -a -n "$rootpasswd" ]; then
        logsh "【$service】" "系统root用户密码将修改为：$rootpasswd"
        echo -e "${rootpasswd}\n${rootpasswd}" | passwd root
    fi
    open_port
    write_firewall_start
    $BIN/${appname} -p ${port} -d $CONF/dropbear_dss_host_key -r $CONF/dropbear_rsa_host_key -b $CONF/banner
    logsh "【$service】" "启动${appname}服务完成！"
    sleep 1
    kill -9 "$(pssh | grep $BIN/${appname} | grep -Ev "[ ]+${port}[ ]+" | awk '{print$1}' | tr '\n' ' ')" && sleep 1

        
}

stop() {

    logsh "【$service】" "正在停止${appname}服务... "
    [ "$enable" == '0' ] && destroy
    close_port
    remove_firewall_start

}

destroy() {
        
    # End app, Scripts here 
    # cru d "${appname}"
    logsh "【$service】" "如果终止${appname}将会在重启后生效！"
    # kill -9 "$(pssh | grep $BIN/${appname} | awk '{print$1}' | tr '\n' ' ')" && sleep 1
    return

}

end() {

    mbdb set $appname.main.enable=0
    stop && exit 1

}

status() {

    if [ -n "$(pssh | grep $BIN/${appname})" ]; then
            status="运行端口号：${port}|1"
    else
            status="未运行|0"
    fi
    mbdb set ${appname}.main.status="$status" 
}

case "$1" in
    start) start ;;
    stop) stop ;;
    restart) stop; start; ;;
    reload) close_port && open_port ;;
    status) status ;;
esac


