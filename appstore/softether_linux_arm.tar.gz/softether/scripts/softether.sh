#!/bin/sh 
source /etc/mixbox/bin/base
eval `mbdb export softether`


ports="1194 500 4500 1701 443 5555 8888 992"
OPKG=/opt/bin/opkg


auto_start_enable() {
        local appname=entware
        local uciname=app
        mbdb set "softether" "1"
}

auto_start_disable() {
        local appname=entware
        local uciname=app
        mbdb del "softether"
}

start() {

        [ -n "$(pidof ${appname})" ] && logsh "【$service】" "${appname}已经在运行！" && exit 1
        logsh "【$service】" "正在启动${appname}服务... "
        cru a "${appname}" "0 6 * * * $FUN/${appname}.sh restart"
        # Scripts Here
        if [ -z "$($OPKG list-installed | grep softethervpn)" ]; then
                logsh "【$service】" "正在opkg安装${appname}程序..."
                $OPKG install softethervpn
                [ $? -ne 0 ] && logsh "【$service】" "安装失败！请检查Entware环境！" && exit 1
        fi
        # 添加entware识别
        auto_start_enable
        # 开放端口
        if [ "$openport" = '1' ]; then
                for port in ${port}s; do
                        iptables -I INPUT -p tcp --dport ${port} -m comment --comment "mixbox-${appname}" -j ACCEPT 
                done
        fi

        daemon $BIN/${appname}
        [ $? -ne 0 ] && logsh "【$service】" "启动${appname}服务失败！" && end
        logsh "【$service】" "启动${appname}服务完成！"
        
}

stop() {

        logsh "【$service】" "正在停止${appname}服务... "
        [ "$enable" == '0' ] && destroy
        
        kill -9 "$(pidof ${appname})"
        

}

destroy() {
        
        # End app, Scripts here 
        cru d "${appname}"
        auto_start_disable
        return

}

end() {

        mbdb set $appname.main.enable=0
        
        stop && exit 1

}

status() {

        if [ -n "$(pidof ${appname})" ]; then
                status="运行中|1"
        else
                status="未运行|0"
        fi
        mbdb set $appname.main.status="$status" 
}

